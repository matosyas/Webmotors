<?php

$sexo = 'M'; 
// Verifica o valor informado e imprime a mensagem correspondente
if ($sexo == 'M') {
    echo "M - Masculino";
} elseif ($sexo == 'F') {
    echo "F - Feminino";
} else {
    echo "Sexo Inválido";
}
?>