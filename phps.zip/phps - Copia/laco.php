<?php

for ($i = 1; $i <= 15; $i++) {
    echo "Como é bom programar PHP.<br>";
}

?>

