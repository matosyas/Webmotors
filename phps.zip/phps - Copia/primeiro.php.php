<?php
    echo"joaquim da silva<br>";
    $teste = 5;
    $a = "6 sorvetes";

    $c = 3;
    $b = "3";

    echo $c== $b;

?>