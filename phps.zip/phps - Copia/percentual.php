<html>
    <body>
<!--- 
    action para onde vai após o clique no botao submit

    method
    POST passa escondido
    GET passa os dados pela URL
-->
<form action=# method=post>
    Nota: <input type=text name=nota required> <br>
    Percentual Faltas: <input type=text name=perc required> <br>
    <input type=submit name=botao value=Mostrar>
</form>
     
    <?php
// nota 7 perc_faltas 25
if (@$_REQUEST['botao']); {
    $nota = $_POST ['nota']; 
    $perc_faltas = $_POST ['perc'];

if ($nota >= 7 && $perc_faltas <= 25) 
    echo "passou  ";
 else echo "reprovou ";

 echo"<br>Nota: ".$nota;
 echo"<br>Faltas: ".$perc_faltas. "%";
}
?>
    <body>
<html>



