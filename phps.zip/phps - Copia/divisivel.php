<?php

for ($i = 0; $i < 180; $i += 2) {
    echo $i . "<br>";
}

?>
