<?php
$trecho1 = "Programar em ";
$trecho2 = "PHP ";
$trecho3 = "é muito fácil!";

echo $trecho1 . $trecho2 . $trecho3;
?>