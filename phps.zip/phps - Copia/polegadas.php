<?php
// Quantidade de chuva em polegadas
$polegadas = 5; // Exemplo: 5 polegadas

// Conversão para milímetros
$milimetros = $polegadas * 25.4;

echo "$polegadas polegadas de chuva equivalem a $milimetros milímetros.";
?>