<?php
	$valor = 24;
	$total = $valor *(15/3)+(17-(3*2)/2);
	echo $total;
?>
