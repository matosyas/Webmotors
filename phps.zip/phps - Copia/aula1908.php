<?php
 $valorA = 5;
 $valorB = 10;

 //. para concatenar

if ($valorA > $valorB) 
    echo "O valor ". $valorA . "é maior";
 else if ($valorA < $valorB) 
    echo "O valor ". $valorB . "é maior";
else 
    echo "iguais"; 



?>