<?php   
$media = 7;

if($media >= 6) {
    echo "O aluno está aprovado";
} elseif ($media < 3) {
    echo "O aluno reprovou automaticamente";
} elseif ($media = 3 | 4 | 5){
    echo "O aluno está em exame";
}    

?>


