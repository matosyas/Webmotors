<?php
$valor1 = 50;
$valor2 = 12;
$resto = $valor1 % $valor2;

echo "O resto da divisão é igual a: " .$resto;


?>