<?php
echo "<script>alert('Voc� saiu!');top.location.href='login.php';</script>"; 
?>