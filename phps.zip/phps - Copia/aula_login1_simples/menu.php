<html>
<body>
<br><br><br><br><br><br><br><br><br><br>
<font size=7 color=red> Entrei </font>
<br><br><br> <a href="logout.php"> sair </a>
</table>