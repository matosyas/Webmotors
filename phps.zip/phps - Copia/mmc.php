<?php

$altura = 1.75; 


$sexo = 'M'; // Substitua por 'F' para feminino

// Calcula o peso ideal com base no sexo
if ($sexo == 'M') {
    $pesoIdeal = (72.7 * $altura) - 58;
    echo "Peso ideal para um homem de altura $altura m: " . number_format($pesoIdeal, 2) . " kg";
} elseif ($sexo == 'F') {
    $pesoIdeal = (62.1 * $altura) - 44.7;
    echo "Peso ideal para uma mulher de altura $altura m: " . number_format($pesoIdeal, 2) . " kg";
} else {
    echo "Sexo inválido. Informe 'M' para masculino ou 'F' para feminino.";
}
?>
