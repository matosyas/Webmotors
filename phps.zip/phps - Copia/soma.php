<?php
$valor1 = 286;
$valor2 = 234;


$resultado = $valor1 + $valor2;

echo "O número que somado a " .$valor1. " totalizando " .$resultado. " é: " .$valor2;

?>