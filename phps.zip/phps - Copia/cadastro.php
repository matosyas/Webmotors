<html>
    <form action=# method=POST>
    Nome: <input type=text name="nome"> <br>
        <br>
    Idade: <input type=text name="idade"> <br>
        <br>
    <input type=submit name=botao value="Salvar">
        <br>
        <br>
        <br>
    Cod: <input type=text name="codigo">
    <input type=submit name=botao value="Deletar">
        <br>
        <br>
    Nome: <input type=text name="nome"> <br>
        <br>
    Materia: <input type=text name="materia"> <br>
        <br>
    Salario: <input type=text name="salario"> <br>
        <br>
    Turno: <input type=text name="turno"> <br>
        <br>
    <input type=submit name=botao value = "Salvar Professor">
        <br>
        <br>
    Cod: <input type=text name="codigo1">
    <input type=submit name=botao value="Deletar Professor">


</form>

<?php
include ('config.php');

if (@$_REQUEST['botao'] =="Salvar"){
    $nome = $_POST['nome'];
    $idade = $_POST ['idade'];
    echo $nome.$idade;

    $query = "INSERT into aluno (nome, idade)
    values ('$nome', '$idade')";
    $result = mysqli_query($con, $query);
}

if (@$_REQUEST ['botao']== "Deletar"){
    $codigo = $_POST['codigo'];

    $query = "DELETE from aluno where id = '
    $codigo'";
    $result = mysqli_query($con, $query);
}

if (@$_REQUEST['botao'] =="Salvar Professor"){
    $nome = $_POST['nome'];
    $materia = $_POST ['materia'];
    $salario = $_POST ['salario'];
    $turno = $_POST ['turno'];
    //echo $nome.$idade;

    $query = "INSERT into professor (nome, materia, salario, turno)
    values ('$nome', '$materia', '$salario', '$turno')";
    $result = mysqli_query($con, $query);
}

if (@$_REQUEST ['botao']== "Deletar Professor"){
    $codigo = $_POST['codigo1'];

    $query = "DELETE from Professor where id = '
    $codigo'";
    $result = mysqli_query($con, $query);
}
?>