<?php
//dentro da pasta de arquivos (htcdocs)
echo "teste";



?>