<html>
<body>
<meta charset=utf-8>
<font size=7 color=red> Entrei no Relatório - <?php require('verifica.php'); echo $_SESSION["nome_usuario"]; ?></font>
</body>
</html>