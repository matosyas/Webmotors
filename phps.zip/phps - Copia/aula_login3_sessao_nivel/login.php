<?php
include ('config.php');
session_start(); // inicia a sessao	


if (@$_REQUEST['botao']=="Entrar")
{
	$login = $_POST['login'];
	$senha = md5($_POST['senha']);
	
	$query = "SELECT * FROM usuario WHERE login = '$login' AND senha = '$senha' ";
	$result = mysqli_query($con, $query);
	while ($coluna=mysqli_fetch_array($result)) 
	{
		$_SESSION["id_usuario"]= $coluna["id"]; 
		$_SESSION["nome_usuario"] = $coluna["login"]; 
		$_SESSION["UsuarioNivel"] = $coluna["nivel"];

		// caso queira direcionar para páginas diferentes
		$niv = $coluna['nivel'];
		if($niv == "USER"){ 
			header("Location: menu.php"); 
			exit; 
		}
		
		if($niv == "ADM"){ 
			header("Location: menu.php"); 
			exit; 
		}
		// ----------------------------------------------
	}
	
}


?>



<form action="login.php" method="post" name="login">
<table width="200" border="1">
  <tr>
    <td colspan="2">Login Anunciantes</td>
  </tr>
  <tr>
    <td width="53">Cod.</td>
    <td width="131"><?php echo @$_POST['id']; ?>&nbsp;
  </tr>
  <tr>
    <td>Login:</td>
    <td><input type="text" name="login" value="<?php echo @$_POST['login']; ?>"></td>
  </tr>
  <tr>
    <td>Senha:</td>
    <td><input type="text" name="senha" value="<?php echo @$_POST['senha']; ?>"></td>
  </tr>

  <tr>
    <td colspan="2" align="right"><input type="submit" value="Entrar" name="botao"> 
    
	<input type="hidden" name="id" value="<?php echo @$_REQUEST['id'] ?>" />
</td>
    </tr>	
</table>
</form>


</body>
</html>

