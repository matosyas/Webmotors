<html>
<head>
<title>Relat&oacute;rio de Clientes</title>
<?php include ('config.php');  ?>
</head>

<body>
<form action="clientelst.php?botao=gravar" method="post" name="form1">

<table width="95%" border="1" align="center">
  <tr>
    <td colspan=5 align="center">Relat&oacute;rio de Clientes</td>
  </tr>
  <tr>
    <td width="18%" align="right">Nome:</td>
    <td width="26%"><input type="text" name="nome"  /></td>
    
    <td width="17%" align="right">Idade:</td>
    <td width="18%"><input type="text" name="idade" size="3" /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>

    <td width="18%" align="right">Sexo:</td>
    <td width="26%"><input type="radio" name="sexo" value="M" size="3" /></td>
    <td width="26%"><input type="radio" name="sexo" value="F" size="3" /></td>

    <td>Sexo:</td>
    <td><input type="radio" name="sexo" value="M" <?php echo (@$_POST['sexo'] == "M" ? " checked" : "" );?> > Masc
    <input type="radio" name="sexo" value="F" <?php echo (@$_POST['sexo'] == "F" ? " checked" : "" );?> > Fem   
    </td>

    <td width="21%"><input type="submit" name="botao" value="Filtrar" /></td>
  </tr>
</table>
</form>

<?php if ($_REQUEST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#90EE90">
    <th width="5%">C&oacute;d</th>
    <th width="30%">Nome</th>
    <th width="15%">Idade</th>
    <th width="12%">Sexo</th>
    <th width="12%">Telefone</th>
    <th width="12%">Altura</th>
  </tr>

<?php

	$nome = $_POST['nome'];
	$idade = $_POST['idade'];
  $sexo = $_POST['sexo'];

	
	$query = "SELECT *
			  FROM cliente 
			  WHERE id > 0 ";
	$query .= ($nome ? " AND nome LIKE '%$nome%' " : "");
	$query .= ($idade ? " AND idade = '$idade' " : "");
  $query .= ($sexo ? " AND nome LIKE '%$sexo%' " : "");
	$query .= " ORDER by id";
	$result = mysqli_query($con, $query);

/*	
	echo "<pre>";
	echo $query;
	echo mysql_error();
	echo "</pre>";
*/
	while ($coluna=mysqli_fetch_array($result)) 
	{
		

    
  

	?>

    
    <tr>
      <th width="5%"><?php echo $coluna['id']; ?></th>
      <th width="30%"><?php echo $coluna['nome']; ?></th>
      <th width="15%"><?php echo $coluna['idade']; ?></th>
      <th width="12%"><?php echo $coluna['sexo']; ?></th>
      <th width="12%"><?php echo $coluna['telefone']; ?></th>
      <th width="12%"><?php echo $coluna['altura']; ?></th>
        <td>
        <a 
            href="cliente.php?pag=cliente&id=<?php echo $coluna['id']; ?>"
            >Editar</a>
        </td>

    </tr>

    <?php
	
	} // fim while
?>
</table>
<?php	
}
?>
</body>
 