<html>
    <body>
<form action=# method=post>
    Valor nº 1: <input type=text name=valor1 required> <br>
    <br>
    Valor nº 2: <input type=text name=valor2 required> <br>
    <input type=submit name=botao value=Mostrar>
</form>
     
    <?php

    @$_REQUEST['botao']; 
    $valor1 = $_POST ['valor1']; 
    $valor2 = $_POST ['valor2'];
    $resultado = $valor1 + $valor2;

 echo"O resultado da soma é: " .$resultado;

?>
    <body>
<html>
